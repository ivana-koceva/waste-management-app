public interface SubmissionsRepository {
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

    public interface SubmissionRepository extends JpaRepository<Submission, Long> {



        @Query("SELECT s FROM Submission s WHERE s.severity = (SELECT MAX(s2.severity) FROM Submission s2)")
        List<Submission> findSubmissionsWithHighestSeverity();

    }


}
