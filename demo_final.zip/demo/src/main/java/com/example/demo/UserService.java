@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserByUsername(String username) {
        return userRepository.findById(username).orElse(null);
    }

    public User createUser(User user) {
        // You may want to perform additional validations here
        return userRepository.save(user);
    }

    public User updateUser(String username, User updatedUser) {
        User existingUser = userRepository.findById(username).orElse(null);
        if (existingUser != null) {
            // Update user properties
            existingUser.setName(updatedUser.getName());
            existingUser.setLastName(updatedUser.getLastName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPassword(updatedUser.getPassword());
            existingUser.setPoints(updatedUser.getPoints());

            // Save the updated user
            return userRepository.save(existingUser);
        }
        return null; // User not found
    }

    public void deleteUser(String username) {
        userRepository.deleteById(username);
    }

    // Other user-related methods
}
