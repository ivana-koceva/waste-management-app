-- src/main/resources/data.sql

INSERT INTO user (username, name, lastName, email, password, points) VALUES
('dddd', 'bbb', 'ggg', 'je@yahoo.com', 'password', 100);

INSERT INTO submission (date, status, category, location, username, image) VALUES
(CURRENT_DATE, 'Pending', 'Category 1', 'Location 1', 'dddd' 'timage.jpg');
