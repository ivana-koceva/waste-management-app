package com.example.demo;
@RestController
@RequestMapping("/api/submissions")
public class SubmissionController {

    @Autowired
    private SubmissionService submissionService;

    @GetMapping
    public List<Submission> getAllSubmissions() {
        return submissionService.getAllSubmissions();
    }

    @GetMapping("/{subId}")
    public ResponseEntity<Submission> getSubmissionById(@PathVariable Long subId) {
        Submission submission = submissionService.getSubmissionById(subId);
        return ResponseEntity.ok(submission);
    }

    @PostMapping
    public ResponseEntity<Submission> createSubmission(@RequestBody Submission submission) {
        Submission createdSubmission = submissionService.createSubmission(submission);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdSubmission);
    }

    @DeleteMapping("/{subId}")
    public ResponseEntity<Void> deleteSubmission(@PathVariable Long subId) {
        submissionService.deleteSubmission(subId);
        return ResponseEntity.noContent().build();
    }

    // Other submission-related endpoints
}


