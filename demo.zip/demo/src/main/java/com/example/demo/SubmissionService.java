package com.example.demo;
@Service
public class SubmissionService {

    @Autowired
    private SubmissionRepository submissionRepository;

    public List<Submission> getAllSubmissions() {
        return submissionRepository.findAll();
    }

    public Submission getSubmissionById(Long subId) {
        return submissionRepository.findById(subId)
                .orElseThrow(() -> new NoSuchElementException("Submission not found with ID: " + subId));
    }

    public Submission createSubmission(Submission submission) {
        return submissionRepository.save(submission);
    }

    public void deleteSubmission(Long subId) {
        submissionRepository.deleteById(subId);
    }

    // Other submission-related methods
}


